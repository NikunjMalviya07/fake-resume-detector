import { GoogleGenerativeAI } from '@google/generative-ai';

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

export async function extractResumeData(rawText) {
  const model = genAI.getGenerativeModel({
    model: 'gemini-3.5-flash',
    generationConfig: { responseMimeType: 'application/json' }
  });

const prompt = `
Extract structured data from this resume text and return ONLY valid JSON matching this exact schema:

{
  "name": string,
  "email": string,
  "phone": string,
  "college": string,
  "degree": string,
  "cgpa": string | null,
  "passingYear": string,
  "skills": [string],
  "projects": [{ "title": string, "description": string, "githubUrl": string | null, "techStack": [string] }],
  "experience": [{ "company": string, "role": string, "duration": string }],
  "githubUsername": string | null,
  "linkedinUrl": string | null
}

Important: resumes exported from certain PDF tools sometimes have corrupted character encoding where letters and digits get visually confused (e.g. "l" instead of "1", "O" instead of "0", "!l" instead of "I"). When extracting email addresses, GitHub usernames, and other alphanumeric identifiers, use context to correct obvious cases of this (e.g. "officialmalviyal4@gmail.com" is almost certainly "officialmalviya14@gmail.com", since email usernames don't typically end in a lowercase letter right after a name). Do NOT alter normal prose text, names, or anything that isn't clearly a character-encoding artifact. If uncertain, keep the original.

If a field isn't present in the resume, use null or an empty array. Do not invent information.

Resume text:
"""
${rawText}
"""
`;

  const result = await model.generateContent(prompt);
  return JSON.parse(result.response.text());
}