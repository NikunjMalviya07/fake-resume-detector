export function calculateScore(verification) {
  const breakdown = [];

  // Education check
  if (verification.education) {
    const edu = verification.education;
    if (edu.status === 'pass') {
      breakdown.push({ check: 'Education match', status: 'pass', weight: 8, note: `Matched: ${edu.matchedInstitution}` });
    } else if (edu.status === 'partial') {
      breakdown.push({ check: 'Education match', status: 'partial', weight: 8, note: 'Institution matched but degree mismatch' });
    } else if (edu.status === 'not_recognized') {
      breakdown.push({ check: 'Education match', status: 'uncertain', weight: 8, note: edu.reason });
    } else {
      breakdown.push({ check: 'Education match', status: 'uncertain', weight: 8, note: 'No college extracted' });
    }
  }

  // GitHub check
  if (verification.github) {
    const gh = verification.github;
    if (gh.status === 'pass') {
      breakdown.push({ check: 'GitHub profile exists', status: 'pass', weight: 6, note: `${gh.profile.publicRepos} public repos` });
      if (gh.skillMatch?.ratio !== null) {
        const ratioStatus = gh.skillMatch.ratio >= 0.3 ? 'pass' : 'fail';
        breakdown.push({
          check: 'Skills match GitHub activity',
          status: ratioStatus,
          weight: 7,
          note: `${Math.round(gh.skillMatch.ratio * 100)}% of claimed skills found in repos`
        });
      }
    } else if (gh.status === 'fail') {
      breakdown.push({ check: 'GitHub profile exists', status: 'fail', weight: 6, note: gh.reason });
    } else {
      breakdown.push({ check: 'GitHub profile exists', status: 'uncertain', weight: 6, note: gh.reason || 'Not checked' });
    }
  }

  // Email check (placeholder until Phase 7 is wired in)
  if (verification.email) {
    breakdown.push({ check: 'Email verification', status: 'uncertain', weight: 3, note: 'Pending verification' });
  }

  // Weighted score: pass=1, partial=0.5, uncertain=0.4, fail=0
  const outcomeValue = { pass: 1, partial: 0.5, uncertain: 0.4, fail: 0 };
  let totalWeight = 0;
  let earnedWeight = 0;

  for (const item of breakdown) {
    totalWeight += item.weight;
    earnedWeight += item.weight * (outcomeValue[item.status] ?? 0.4);
  }

  const finalScore = totalWeight > 0 ? Math.round((earnedWeight / totalWeight) * 100) : null;

  let bucket;
  if (finalScore === null) bucket = 'Not assessed';
  else if (finalScore >= 80) bucket = 'High credibility';
  else if (finalScore >= 50) bucket = 'Needs review';
  else bucket = 'High risk';

  return {
    finalScore,
    bucket,
    breakdown
  };
}