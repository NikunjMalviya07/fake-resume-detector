import Fuse from 'fuse.js';
import Institution from '../model/Institution.js';

export async function verifyEducation(structuredData) {
  const { college, degree, email } = structuredData;

  if (!college) {
    return { status: 'uncertain', reason: 'No college name extracted from resume' };
  }

  const institutions = await Institution.find({});

  const fuse = new Fuse(institutions, {
    keys: ['name', 'aliases'],
    threshold: 0.4,
    includeScore: true
  });

  const results = fuse.search(college);

if (results.length === 0) {
    return {
      status: 'not_recognized',
      reason: `"${college}" was not found in our verified institutions database. This does not necessarily indicate fraud — it may mean the institution isn't yet in our dataset.`
    };
  }

  const bestMatch = results[0].item;
  const matchConfidence = 1 - results[0].score;

  // Partial/contains match instead of exact — a resume's degree phrasing
  // ("B.Tech in Computer Science & Engineering") will rarely match a
  // clean list entry ("B.Tech") exactly.
  const degreeMatch = degree
    ? bestMatch.recognizedDegrees.some(d =>
        degree.toLowerCase().includes(d.toLowerCase())
      )
    : null;

  // Email domain mismatch is common and NOT inherently suspicious —
  // most students list a personal email. Treat it as informational only,
  // never as a fail condition.
  const emailDomainMatch = email && bestMatch.emailDomain
    ? email.toLowerCase().endsWith(bestMatch.emailDomain.toLowerCase())
    : null;

  const checks = {
    collegeMatch: {
      matched: true,
      matchedName: bestMatch.name,
      confidence: matchConfidence
    },
    degreeMatch,
    emailDomainMatch
  };


  const allPass = checks.collegeMatch.matched && (checks.degreeMatch !== false);

  return {
    status: allPass ? 'pass' : 'partial',
    matchedInstitution: bestMatch.name,
    confidence: matchConfidence,
    checks
  };
}