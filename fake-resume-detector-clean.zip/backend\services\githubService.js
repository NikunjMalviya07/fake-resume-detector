import axios from 'axios';

const GITHUB_API = 'https://api.github.com';
const headers = {
  Authorization: `Bearer ${process.env.GITHUB_TOKEN}`,
  Accept: 'application/vnd.github+json'
};

export async function verifyGithub(structuredData) {
  const { githubUsername, skills = [] } = structuredData;

  if (!githubUsername) {
    return { status: 'uncertain', reason: 'No GitHub username found on resume' };
  }

  try {
    const userRes = await axios.get(`${GITHUB_API}/users/${githubUsername}`, { headers });
    const profile = userRes.data;

    const reposRes = await axios.get(
      `${GITHUB_API}/users/${githubUsername}/repos?per_page=100&sort=updated`,
      { headers }
    );
    const repos = reposRes.data;

    const ownRepos = repos.filter(r => !r.fork);
    const forkedRepos = repos.filter(r => r.fork);

    // Aggregate languages across the user's own (non-forked) repos
    const languageSet = new Set();
    for (const repo of ownRepos.slice(0, 15)) { // cap to avoid burning rate limit
      try {
        const langRes = await axios.get(`${GITHUB_API}/repos/${repo.full_name}/languages`, { headers });
        Object.keys(langRes.data).forEach(lang => languageSet.add(lang.toLowerCase()));
      } catch {
        continue; // skip repos that error out, don't fail the whole check
      }
    }
    const languages = Array.from(languageSet);

    // Compare claimed skills against actual languages used in real repos
    const normalizedSkills = skills.map(s => s.toLowerCase());
    const matchedSkills = normalizedSkills.filter(skill =>
      languages.some(lang => lang.includes(skill) || skill.includes(lang))
    );
    const skillMatchRatio = normalizedSkills.length > 0
      ? matchedSkills.length / normalizedSkills.length
      : null;

    return {
      status: 'pass',
      profile: {
        username: profile.login,
        name: profile.name,
        publicRepos: profile.public_repos,
        accountCreated: profile.created_at
      },
      repoSummary: {
        ownRepoCount: ownRepos.length,
        forkedRepoCount: forkedRepos.length
      },
      languagesFound: languages,
      skillMatch: {
        matchedSkills,
        ratio: skillMatchRatio,
        note: skillMatchRatio !== null && skillMatchRatio < 0.3
          ? 'Claimed skills show little overlap with actual repository languages'
          : null
      }
    };
  } catch (err) {
    if (err.response?.status === 404) {
      return { status: 'fail', reason: `GitHub user "${githubUsername}" does not exist` };
    }
    return { status: 'error', reason: `GitHub verification failed: ${err.message}` };
  }
}